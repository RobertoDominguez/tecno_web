const axios = require("axios");
require('../css/keyframes.css');
require('../css/banner.css');
require('../css/style.css');

AOS.init();

